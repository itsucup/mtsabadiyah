<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <title>MTs Abadiyah - Berita</title>
</head>
<body class="font-inter pt-20 md:pt-24">

    <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="font-inter bg-emerald-50 mx-5 md:mx-20 my-6 p-4 rounded-lg shadow-sm">
        <div class="flex items-center text-sm text-slate-500 space-x-1">
            <a class="hover:text-emerald-600 font-medium transition-colors duration-200" href="<?php echo e(route('beranda')); ?>">Home</a>
            <span>></span>
            <span class="text-emerald-700 font-semibold">Berita</span>
        </div>
    </section>

    <section class="mx-5 md:mx-20 mb-10">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">

            <div class="md:col-span-2 space-y-6">
                <?php $__empty_1 = true; $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="bg-white shadow-md rounded-lg overflow-hidden">
                        <?php if($berita->header_url): ?> 
                            <img src="<?php echo e($berita->header_url); ?>" alt="<?php echo e($berita->judul); ?>" class="w-full h-80 object-cover">
                        <?php else: ?>
                            <div class="w-full h-80 bg-gray-200 flex items-center justify-center text-gray-500 text-lg">No Image</div>
                        <?php endif; ?>
                        <div class="p-4">
                            <a href="<?php echo e(route('berita.show', $berita->id)); ?>" class="text-xl font-semibold text-emerald-700 hover:text-emerald-900 transition-colors duration-200"><?php echo e($berita->judul); ?></a>
                            <p class="text-sm text-gray-500 mb-2"><?php echo e($berita->created_at->translatedFormat('d F Y')); ?> oleh <?php echo e($berita->user->name ?? 'Anonim'); ?></p>
                            <p class="text-gray-700 mb-3"><?php echo e(Str::limit(strip_tags($berita->konten), 200)); ?></p>
                            <a href="<?php echo e(route('berita.show', $berita->id)); ?>" class="text-emerald-600 hover:text-emerald-900 text-sm font-medium">Baca Selengkapnya →</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-span-full text-center text-gray-600 py-10">
                        <p class="text-lg">Belum ada berita yang aktif.</p>
                    </div>
                <?php endif; ?>

                <div class="flex justify-center mt-8">
                    
                    <?php echo e($beritas->appends(request()->query())->links()); ?>

                </div>
            </div>

            <aside class="space-y-6">
                
                <div class="bg-white p-4 rounded-lg shadow-md">
                    <h3 class="text-lg font-semibold text-emerald-700 mb-2">Cari Berita</h3>
                    <form action="<?php echo e(route('berita.index')); ?>" method="GET">
                        <div class="flex items-center border border-gray-300 rounded focus-within:ring-2 focus-within:ring-emerald-500">
                            <input type="text" name="search" placeholder="Cari judul atau konten..." value="<?php echo e(request('search')); ?>"
                                   class="w-full p-2 border-none focus:outline-none focus:ring-0 rounded-l">
                            <button type="submit" class="px-3 py-2 bg-emerald-600 text-white rounded-r hover:bg-emerald-700 transition duration-200">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>
                </div>

                
                <div class="bg-white p-4 rounded-lg shadow-md">
                    <h3 class="text-lg font-semibold text-emerald-700 mb-2">Kategori</h3>
                    <ul class="text-gray-700 space-y-1">
                        <li><a href="<?php echo e(route('berita.index', array_merge(request()->except('kategori', 'page'), ['kategori' => null]))); ?>" class="block py-1 hover:text-emerald-600 transition-colors duration-200 <?php echo e(!request('kategori') ? 'font-bold text-emerald-700' : ''); ?>">Semua Kategori</a></li>
                        <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <hr class="my-1 border-gray-200" />
                            <li>
                                <a href="<?php echo e(route('berita.index', array_merge(request()->except('kategori', 'page'), ['kategori' => $kategori->slug]))); ?>"
                                   class="block py-1 hover:text-emerald-600 transition-colors duration-200 <?php echo e(request('kategori') == $kategori->slug ? 'font-bold text-emerald-700' : ''); ?>">
                                    <?php echo e($kategori->nama); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                
                <div class="bg-white p-4 rounded-lg shadow-md">
                    <h3 class="text-lg font-semibold text-emerald-700 mb-2">Arsip Berita</h3>
                    <ul class="text-gray-700 space-y-1">
                        <?php $__currentLoopData = $archiveYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year => $months): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="relative">
                                <button class="w-full text-left py-1 hover:text-emerald-600 transition-colors duration-200 <?php echo e(request('year') == $year ? 'font-bold text-emerald-700' : ''); ?>"
                                    onclick="document.getElementById('archive-year-<?php echo e($year); ?>').classList.toggle('hidden');">
                                    <?php echo e($year); ?> <i class="fas fa-chevron-down text-xs ml-2"></i>
                                </button>
                                <ul id="archive-year-<?php echo e($year); ?>" class="pl-4 mt-1 space-y-1 <?php echo e(request('year') == $year ? '' : 'hidden'); ?>">
                                    <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(route('berita.index', array_merge(request()->except('month', 'page'), ['year' => $year, 'month' => $month['month_num']]))); ?>"
                                               class="block py-1 text-sm hover:text-emerald-600 transition-colors duration-200 <?php echo e(request('month') == $month['month_num'] && request('year') == $year ? 'font-bold text-emerald-700' : ''); ?>">
                                                <?php echo e($month['month_name']); ?> (<?php echo e($month['count']); ?>)
                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                            <hr class="my-1 border-gray-200" />
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <li><a href="<?php echo e(route('berita.index', array_merge(request()->except('year', 'month', 'page'), ['year' => null, 'month' => null]))); ?>" class="block py-1 hover:text-emerald-600 transition-colors duration-200 <?php echo e(!request('year') ? 'font-bold text-emerald-700' : ''); ?>">Semua Arsip</a></li>
                    </ul>
                </div>
            </aside>

        </div>
    </section>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html><?php /**PATH C:\laragon\www\mtsabadiyah\resources\views\berita\index.blade.php ENDPATH**/ ?>