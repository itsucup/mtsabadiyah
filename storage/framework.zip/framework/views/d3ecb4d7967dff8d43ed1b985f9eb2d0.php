

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto">
        <h1 class="text-3xl font-bold text-gray-800 mb-6 border-b-4 border-emerald-600 pb-2 inline-block">Edit Slider</h1>

        <div class="bg-white shadow-md rounded-lg p-6">
            <form action="<?php echo e(route('cms.admin.header_sliders.update', $slider)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-4">
                    <label for="image" class="block text-gray-700 text-sm font-bold mb-2">Gambar Slider:</label>
                    <?php if($slider->image_url): ?>
                        <img src="<?php echo e($slider->image_url); ?>" alt="Current Slider Image" class="w-32 h-24 object-cover rounded mb-2">
                    <?php endif; ?>
                    <input type="file" name="image" id="image" accept="image/*"
                           class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <p class="text-xs text-gray-500 mt-1">Pilih gambar baru jika ingin mengubah. Max: 5MB.</p>
                    <div class="mt-2">
                        <label class="inline-flex items-center">
                            <input type="checkbox" name="delete_image" value="1" class="form-checkbox h-5 w-5 text-red-600">
                            <span class="ml-2 text-sm text-red-700">Hapus Gambar</span>
                        </label>
                    </div>
                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs italic"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                
                <div class="flex justify-end space-x-3">
                    <a href="<?php echo e(route('cms.admin.header_sliders.index')); ?>" class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transition duration-200">
                        Batal
                    </a>
                    <button type="submit" class="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transition duration-200">
                        Simpan Perubahan
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\mtsabadiyah\resources\views\cms\admin\header_sliders\edit.blade.php ENDPATH**/ ?>