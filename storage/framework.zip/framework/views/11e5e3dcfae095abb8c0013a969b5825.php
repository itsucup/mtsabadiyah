<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <title>Ekstrakulikuler</title>
    <style>
        details summary::-webkit-details-marker {
            display: none;
        }
        summary {
            list-style: none;
        }
        details summary {
            cursor: pointer;
        }
    </style>
</head>
<body class="font-inter pt-20 md:pt-24">

    <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="bg-emerald-50 mx-4 md:mx-20 my-6 p-4 rounded-lg shadow-sm">
        <div class="flex items-center text-sm text-slate-500 space-x-1">
            <a href="/" class="hover:text-emerald-600 font-medium transition-colors duration-200">Home</a>
            <span>></span>
            <a href="<?php echo e(route('profil.ekstrakulikuler')); ?>" class="hover:text-emerald-600 font-medium transition-colors duration-200">Profil</a>
            <span>></span>
            <span class="text-emerald-700 font-semibold">Ekstrakulikuler</span>
        </div>
    </section>

    <section class="mx-4 md:mx-20 my-10">
        <h1 class="pb-6 text-3xl font-semibold text-center text-gray-800">Ekstrakulikuler</h1>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">

            <?php $__empty_1 = true; $__currentLoopData = $ekstrakulikulers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ekstra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <details class="bg-white rounded-xl shadow hover:shadow-md transition group cursor-pointer overflow-hidden">
                    <summary class="p-4">
                        <div class="flex flex-col items-center text-center">
                            <?php if($ekstra->foto_icon): ?>
                                <img src="<?php echo e($ekstra->foto_icon); ?>" alt="<?php echo e($ekstra->nama); ?>" class="w-16 h-16 mb-3 object-contain rounded" />
                            <?php else: ?>
                                <div class="w-16 h-16 mb-3 bg-gray-200 rounded-full flex items-center justify-center text-gray-500 text-xs">No Icon</div>
                            <?php endif; ?>
                            <h3 class="font-semibold text-lg text-gray-800"><?php echo e($ekstra->nama); ?></h3>
                        </div>
                    </summary>
                    <div class="px-4 pb-4 text-sm text-gray-600">
                        <?php echo e($ekstra->deskripsi_singkat); ?>

                    </div>
                </details>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-span-full text-center text-gray-600 py-10">
                    <p class="text-lg">Belum ada ekstrakulikuler yang aktif.</p>
                </div>
            <?php endif; ?>

        </div>
    </section>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>
</html><?php /**PATH C:\laragon\www\mtsabadiyah\resources\views\profil\ekstrakulikuler.blade.php ENDPATH**/ ?>