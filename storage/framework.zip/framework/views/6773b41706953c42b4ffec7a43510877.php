<footer class="">
  <div class="bg-emerald-700 text-white pt-6 pb-6 px-6 md:px-20 grid grid-cols-1 md:grid-cols-3 gap-10">

    <div>
      <div class="flex items-center space-x-4 mb-4">
        <img 
        src="<?php echo e($lembagaSettings->logo_url ?? asset('images/default_logo.png')); ?>" 
        alt="<?php echo e($lembagaSettings->nama_lembaga ?? 'Logo MTs Abadiyah'); ?>" 
        class="w-12 h-12 object-contain" 
        />
        <h3 class="text-xl font-bold"><?php echo e($lembagaSettings->nama_lembaga ?? 'MTs Abadiyah'); ?></h3>
      </div>
      <p class="text-sm text-gray-200 leading-relaxed">
        <?php echo e($lembagaSettings->deskripsi_singkat ?? 'MTs Abadiyah Gabus Pati adalah madrasah berbasis pesantren yang mengedepankan pendidikan karakter, akademik, dan spiritual.'); ?>

      </p>
    </div>

    <div>
      <h4 class="text-lg font-semibold mb-4">Kontak Kami</h4>
      <ul class="text-sm space-y-2 text-gray-200">
        <?php if($lembagaSettings->alamat): ?>
          <li class="flex items-start space-x-2">
            <i class="fas fa-map-marker-alt mt-1 w-5"></i>
            <span><?php echo e($lembagaSettings->alamat); ?></span>
          </li>
        <?php endif; ?>
        <?php if($lembagaSettings->no_telepon): ?>
          <li class="flex items-center space-x-2">
            <i class="fas fa-phone w-5"></i>
            <span><?php echo e($lembagaSettings->no_telepon); ?> (Telepon)</span>
          </li>
        <?php endif; ?>
        <?php if($lembagaSettings->no_fax): ?>
          <li class="flex items-center space-x-2">
            <i class="fas fa-fax w-5"></i>
            <span><?php echo e($lembagaSettings->no_fax); ?> (Fax)</span>
          </li>
        <?php endif; ?>
        <?php if($lembagaSettings->email): ?>
          <li class="flex items-center space-x-2">
            <i class="fas fa-envelope w-5"></i>
            <span><?php echo e($lembagaSettings->email); ?></span>
        </li>
        <?php endif; ?>
      </ul>
    </div>

    <div>
      <h4 class="text-lg font-semibold mb-4">Ikuti Kami</h4>
      <div class="flex space-x-4 text-2xl">
        <?php if($lembagaSettings->facebook_url): ?>
          <a href="<?php echo e($lembagaSettings->facebook_url); ?>" target="_blank" aria-label="Facebook" class="hover:text-gray-300 transition">
            <i class="fab fa-facebook-f"></i>
          </a>
        <?php endif; ?>
        <?php if($lembagaSettings->instagram_url): ?>
          <a href="<?php echo e($lembagaSettings->instagram_url); ?>" target="_blank" aria-label="Instagram" class="hover:text-gray-300 transition">
            <i class="fab fa-instagram"></i>
          </a>
        <?php endif; ?>
        <?php if($lembagaSettings->tiktok_url): ?>
          <a href="<?php echo e($lembagaSettings->tiktok_url); ?>" target="_blank" aria-label="TikTok" class="hover:text-gray-300 transition">
            <i class="fab fa-tiktok"></i>
          </a>
        <?php endif; ?>
        <?php if($lembagaSettings->youtube_url): ?>
          <a href="<?php echo e($lembagaSettings->youtube_url); ?>" target="_blank" aria-label="YouTube" class="hover:text-gray-300 transition">
            <i class="fab fa-youtube"></i>
          </a>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="border-t border-gray-600 py-4 text-center text-sm text-gray-50 bg-emerald-900">
    © <?php echo e(date('Y')); ?> <?php echo e($lembagaSettings->nama_lembaga ?? 'MTs Abadiyah Gabus Pati'); ?>. All rights reserved.
  </div>
</footer><?php /**PATH C:\laragon\www\mtsabadiyah\resources\views/partials/footer.blade.php ENDPATH**/ ?>