<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <title><?php echo e($lembagaSettings->nama_lembaga ?? 'MTs Abadiyah Gabus Pati'); ?> - Program Kelas</title>
    <link rel="icon" href="<?php echo e(asset('images/logo_mtsabadiyah.png')); ?>" type="image/png">
</head>
<body class="font-inter pt-20 md:pt-24">

    <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="bg-emerald-50 mx-5 md:mx-20 my-6 p-4 rounded-lg shadow-sm">
        <div class="flex items-center text-sm text-slate-500 space-x-1">
            <a href="<?php echo e(route('beranda')); ?>" class="hover:text-emerald-600 font-medium">Home</a>
            <span>></span>
            <span class="text-emerald-700 font-semibold">Program Kelas</span>
        </div>
    </section>

    <section class="mx-4 md:mx-20 my-10">
        <h1 class="pb-6 text-3xl font-semibold text-center text-gray-800">Program Kelas</h1>

        <div class="space-y-4">
            <?php $__empty_1 = true; $__currentLoopData = $programKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <details class="bg-white shadow rounded overflow-hidden">
                    <summary class="flex items-center px-6 py-4 cursor-pointer hover:bg-emerald-50 space-x-4">
                        <span class="text-lg font-semibold"><?php echo e($program->nama); ?></span>
                    </summary>
                    <div class="px-6 py-4 border-t text-gray-600">
                        <?php if($program->foto_icon): ?>
                            
                            <div class="flex justify-center mb-4"> 
                                <img src="<?php echo e($program->foto_icon); ?>" alt="<?php echo e($program->nama); ?>" class="w-60 h-60 object-cover rounded-lg shadow-md">
                            </div>
                        <?php endif; ?>
                        <p><?php echo e($program->deskripsi); ?></p> 
                    </div>
                </details>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center py-8 text-gray-600">
                    <p>Belum ada program kelas yang tersedia.</p>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>
</html><?php /**PATH C:\laragon\www\mtsabadiyah\resources\views/programkelas.blade.php ENDPATH**/ ?>