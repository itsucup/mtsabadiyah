<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Visi dan Misi</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="font-inter pt-20 md:pt-24">

    <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="bg-emerald-50 mx-4 md:mx-20 my-6 p-4 rounded-lg shadow-sm">
        <div class="flex items-center text-sm text-slate-500 space-x-1">
            <a href="/" class="hover:text-emerald-600 font-medium transition-colors duration-200">Home</a>
            <span>></span>
            <a href="<?php echo e(route('profil.visi_misi')); ?>" class="hover:text-emerald-600 font-medium transition-colors duration-200">Profil</a>
            <span>></span>
            <span class="text-emerald-700 font-semibold">Visi & Misi</span>
        </div>
    </section>

    <section class="mx-4 md:mx-20 mb-10">
        <?php if($visiMisi): ?>
            <?php if($visiMisi->gambar_header): ?>
                <div class="relative w-full aspect-w-15 aspect-h-7 overflow-hidden rounded-lg shadow-md mb-8">
                    <img src="<?php echo e($visiMisi->gambar_header); ?>" alt="Gambar Header Visi dan Misi" class="absolute inset-0 w-full h-full object-cover">
                </div>
            <?php endif; ?>

            <div class="bg-white shadow-md rounded-lg p-6 text-gray-800 leading-relaxed text-justify mb-8">
                <h2 class="text-2xl font-semibold border-l-4 border-emerald-500 pl-1 mb-4">Visi</h2>
                <div class="prose max-w-none prose-emerald lg:prose-lg">
                    <?php
                        $parser = new Parsedown();
                    ?>
                    <?php echo $parser->text($visiMisi->visi ?? ''); ?>

                </div>
            </div>

            <div class="bg-white shadow-md rounded-lg p-6 text-gray-800 leading-relaxed text-justify">
                <h2 class="text-2xl font-semibold border-l-4 border-emerald-500 pl-1 mb-4">Misi</h2>
                <div class="prose max-w-none prose-emerald lg:prose-lg">
                    <?php
                        $parser = new Parsedown();
                    ?>
                    <?php echo $parser->text($visiMisi->misi ?? ''); ?>

                </div>
            </div>

        <?php else: ?>
            <div class="text-center text-gray-600 py-10">
                <p class="text-lg">Konten Visi dan Misi belum tersedia. Silakan hubungi administrator.</p>
            </div>
        <?php endif; ?>
    </section>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>
</html><?php /**PATH C:\laragon\www\mtsabadiyah\resources\views/profil/visi_misi.blade.php ENDPATH**/ ?>