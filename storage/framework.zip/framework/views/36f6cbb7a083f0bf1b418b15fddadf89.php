 

<?php $__env->startSection('content'); ?>
<div class="container mx-auto">
    <h1 class="text-3xl font-bold text-gray-800 mb-6 border-b-4 border-emerald-600 pb-2 inline-block">Manajemen Hymne Abadiyah</h1>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
            <p><strong>Terjadi kesalahan:</strong></p>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="bg-white shadow-md rounded-lg p-6">
        <form action="<?php echo e(route('cms.admin.hymne_abadiyah.store_or_update')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="mb-4">
                <label for="video_url" class="block text-gray-700 text-sm font-bold mb-2">URL Video (Opsional):</label>
                <input type="url" name="video_url" id="video_url" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline <?php $__errorArgs = ['video_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('video_url', $hymne->video_url ?? '')); ?>" placeholder="Contoh: https://www.youtube.com/watch?v=xxxxxxxxxxx">
                <p class="text-xs text-gray-500 mt-1">Masukkan URL video YouTube, Google Drive, atau lainnya.</p>
                <?php $__errorArgs = ['video_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs italic"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php if($hymne && $hymne->video_url): ?>
                    <div class="mt-4">
                        <p class="text-gray-700 text-sm font-bold mb-2">Pratinjau Video:</p>
                        
                        <?php
                            $embedUrl = $hymne->video_url;
                            if (str_contains($embedUrl, 'youtube.com/watch?v=')) {
                                $embedUrl = str_replace('watch?v=', 'embed/', $embedUrl);
                                $embedUrl = explode('&', $embedUrl)[0]; // Hapus parameter tambahan
                            } elseif (str_contains($embedUrl, 'youtu.be/')) {
                                $embedUrl = str_replace('youtu.be/', 'www.youtube.com/embed/', $embedUrl);
                                $embedUrl = explode('?', $embedUrl)[0]; // Hapus parameter tambahan
                            }
                            // Anda bisa menambahkan logika untuk platform video lain (misal Google Drive, Vimeo)
                        ?>
                        <?php if(str_contains($embedUrl, 'youtube.com/embed/')): ?>
                            <iframe class="w-full aspect-video rounded-lg shadow-md" src="<?php echo e($embedUrl); ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        <?php else: ?>
                            <p class="text-red-500 text-sm">URL video tidak dapat dipratinjau atau tidak dikenali sebagai format YouTube.</p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="mb-6">
                <label for="lirik" class="block text-gray-700 text-sm font-bold mb-2">Lirik (Opsional):</label>
                <textarea name="lirik" id="lirik" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline <?php $__errorArgs = ['lirik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="10"><?php echo e(old('lirik', $hymne->lirik ?? '')); ?></textarea>
                <p class="text-xs text-gray-500 mt-1">Anda bisa menggunakan baris baru untuk memisahkan bait.</p>
                <?php $__errorArgs = ['lirik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs italic"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="flex items-center justify-end">
                <button type="submit" class="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transition duration-200">
                    Simpan Perubahan
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\mtsabadiyah\resources\views/cms/admin/hymne_abadiyah/index.blade.php ENDPATH**/ ?>