<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <title><?php echo e($lembagaSettings->nama_lembaga ?? 'MTs Abadiyah Gabus Pati'); ?> - Prestasi</title>
    <link rel="icon" href="<?php echo e(asset('images/logo_mtsabadiyah.png')); ?>" type="image/png">
</head>
<body class="font-inter pt-20 md:pt-24">

    <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="bg-emerald-50 mx-5 md:mx-20 my-6 p-4 rounded-lg shadow-sm">
        <div class="flex items-center text-sm text-slate-500 space-x-1">
            <a class="hover:text-emerald-600 font-medium transition-colors duration-200" href="<?php echo e(route('beranda')); ?>">Home</a>
            <span>></span>
            <span class="text-emerald-700 font-semibold">Prestasi</span>
        </div>
    </section>

    <section class="mx-5 md:mx-20 my-6">
        <div>
            <h2 class="mb-2 text-3xl font-semibold text-gray-800">Data Prestasi</h2>
            <hr class="my-4 border-gray-200">

            
            <div class="mb-6 flex flex-col md:flex-row justify-end items-center space-y-4 md:space-y-0 md:space-x-4">
                <form action="<?php echo e(route('prestasi')); ?>" method="GET" class="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 w-full md:w-auto">
                    <div class="relative w-full md:w-auto">
                        <input type="text" name="search" placeholder="Cari nama/prestasi/instansi..." value="<?php echo e(request('search')); ?>"
                               class="block w-full py-2 px-3 border border-gray-300 rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm">
                        <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                            <i class="text-gray-400"></i>
                        </div>
                    </div>
                    
                    <select name="tahun" class="block w-full md:w-auto py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm">
                        <option value="">Semua Tahun</option>
                        <?php $__currentLoopData = $availableYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($year); ?>" <?php echo e(request('tahun') == $year ? 'selected' : ''); ?>><?php echo e($year); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <button type="submit" class="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded-md shadow transition duration-300 ease-in-out">
                        Filter
                    </button>
                    <?php if(request('search') || request('tahun')): ?>
                        <a href="<?php echo e(route('prestasi')); ?>" class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded-md shadow transition duration-300 ease-in-out flex items-center justify-center">
                            Reset
                        </a>
                    <?php endif; ?>
                </form>
            </div>

            <div class="overflow-x-auto bg-white rounded-lg shadow">
                <table class="min-w-full text-left border border-gray-200">
                    <thead class="bg-emerald-600 text-white">
                        <tr>
                            <th class="px-4 py-2 border-r text-center">No</th>
                            <th class="px-4 py-2 border-r text-center">Nama Lengkap</th>
                            <th class="px-4 py-2 border-r text-center">Nama Prestasi</th>
                            <th class="px-4 py-2 border-r text-center">Tingkat Prestasi</th>
                            <th class="px-4 py-2 border-r text-center">Instansi Penyelenggara</th>
                            <th class="px-4 py-2 text-center">Tahun</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-700">
                        <?php $__empty_1 = true; $__currentLoopData = $prestasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prestasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-100">
                                <td class="px-4 py-2 border-t border-r text-center"><?php echo e($loop->iteration + ($prestasis->currentPage() - 1) * $prestasis->perPage()); ?></td>
                                <td class="px-4 py-2 border-t border-r"><?php echo e($prestasi->nama_lengkap_anggota); ?></td>
                                <td class="px-4 py-2 border-t border-r"><?php echo e($prestasi->nama_prestasi); ?></td>
                                <td class="px-4 py-2 border-t border-r"><?php echo e($prestasi->tingkat_prestasi); ?></td>
                                <td class="px-4 py-2 border-t border-r"><?php echo e($prestasi->instansi_penyelenggara); ?></td>
                                <td class="px-4 py-2 border-t text-center"><?php echo e($prestasi->tahun); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="px-4 py-2 border-t text-center text-gray-600">Belum ada data prestasi.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-4 p-4">
                <?php echo e($prestasis->appends(request()->query())->links()); ?> 
            </div>
        </div>
    </section>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>
</html><?php /**PATH C:\laragon\www\mtsabadiyah\resources\views/prestasi.blade.php ENDPATH**/ ?>