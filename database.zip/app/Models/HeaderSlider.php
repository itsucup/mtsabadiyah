<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HeaderSlider extends Model
{
    use HasFactory;

    protected $table = 'header_sliders';

    protected $fillable = [
        'image_url',
    ];
    protected $casts = [

    ];

}